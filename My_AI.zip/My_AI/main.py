import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import mean_absolute_error, r2_score
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import matplotlib
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

matplotlib.use('TkAgg')


class UberPricePredictor:
    def __init__(self):
        self.df = None
        self.model = None
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.feature_importance = None
        self.feature_names = None

    def load_data(self, file_path):
        """Загрузка и подготовка данных"""
        try:
            self.df = pd.read_csv(file_path)
            initial_count = len(self.df)
            self.df = self.df.dropna(subset=['Booking Value'])
            cleaned_count = len(self.df)

            if initial_count != cleaned_count:
                print(f"Удалено {initial_count - cleaned_count} записей с NaN в Booking Value")
            return self.df
        except Exception as e:
            raise Exception(f"Ошибка загрузки файла {file_path}: {str(e)}")

    def create_additional_features(self):
        """Создание дополнительных факторов"""
        try:
            # Временные факторы
            if 'Date' in self.df.columns and 'Time' in self.df.columns:
                self.df['booking_datetime'] = pd.to_datetime(self.df['Date'] + ' ' + self.df['Time'], errors='coerce')
                self.df = self.df.dropna(subset=['booking_datetime'])
                self.df['hour'] = self.df['booking_datetime'].dt.hour
                self.df['day_of_week'] = self.df['booking_datetime'].dt.dayofweek
                self.df['is_weekend'] = self.df['day_of_week'].isin([5, 6]).astype(int)
                self.df['month'] = self.df['booking_datetime'].dt.month
                self.df['is_peak_hours'] = ((self.df['hour'] >= 7) & (self.df['hour'] <= 9) |
                                            (self.df['hour'] >= 17) & (self.df['hour'] <= 19)).astype(int)
            else:
                np.random.seed(42)
                self.df['hour'] = np.random.randint(0, 24, len(self.df))
                self.df['day_of_week'] = np.random.randint(0, 7, len(self.df))
                self.df['is_weekend'] = (self.df['day_of_week'] >= 5).astype(int)
                self.df['month'] = np.random.randint(1, 13, len(self.df))
                self.df['is_peak_hours'] = ((self.df['hour'] >= 7) & (self.df['hour'] <= 9) |
                                            (self.df['hour'] >= 17) & (self.df['hour'] <= 19)).astype(int)

            # Дополнительные факторы
            np.random.seed(42)
            self.df['temperature'] = np.random.normal(25, 8, len(self.df))
            self.df['precipitation'] = np.random.exponential(0.5, len(self.df))
            self.df['is_rainy'] = (self.df['precipitation'] > 1).astype(int)
            self.df['demand_surge'] = np.random.lognormal(0, 0.3, len(self.df))
            self.df['driver_availability'] = np.random.beta(2, 5, len(self.df))
            self.df['trip_distance_km'] = np.random.gamma(5, 2, len(self.df))
            self.df['estimated_duration_min'] = self.df['trip_distance_km'] * 3 + np.random.normal(0, 5, len(self.df))
            self.df['is_city_center'] = np.random.choice([0, 1], len(self.df), p=[0.7, 0.3])
            self.df['area_traffic_density'] = np.random.beta(2, 3, len(self.df))
            self.df['user_rating'] = np.random.normal(4.5, 0.5, len(self.df)).clip(1, 5)
            self.df['user_experience_level'] = np.random.choice(['new', 'regular', 'veteran'], len(self.df),
                                                                p=[0.2, 0.5, 0.3])
            self.df['fuel_price_index'] = np.random.normal(1.0, 0.1, len(self.df))
            self.df['daylight_hours'] = 12 + 4 * np.sin(2 * np.pi * (self.df['month'] - 3) / 12)
            self.df['is_holiday'] = np.random.choice([0, 1], len(self.df), p=[0.9, 0.1])
            self.df['special_event_multiplier'] = 1 + 0.5 * self.df['is_holiday']

        except Exception as e:
            raise Exception(f"Ошибка создания дополнительных признаков: {str(e)}")

    def prepare_features_for_ml(self):
        """Подготовка признаков для машинного обучения"""
        try:
            y = self.df['Booking Value'].copy()
            if y.isnull().any():
                y = y.fillna(y.median())

            feature_columns = [
                'hour', 'day_of_week', 'is_weekend', 'month', 'is_peak_hours',
                'temperature', 'precipitation', 'is_rainy', 'demand_surge',
                'driver_availability', 'trip_distance_km', 'estimated_duration_min',
                'is_city_center', 'area_traffic_density', 'user_rating',
                'fuel_price_index', 'daylight_hours', 'is_holiday'
            ]

            X = self.df[feature_columns].copy()

            for col in X.columns:
                if X[col].isnull().any():
                    if X[col].dtype in ['float64', 'int64']:
                        X[col] = X[col].fillna(X[col].median())
                    else:
                        X[col] = X[col].fillna(X[col].mode()[0] if not X[col].mode().empty else 0)

            if 'user_experience_level' in self.df.columns:
                self.label_encoders['user_experience_level'] = LabelEncoder()
                self.df['user_experience_level'] = self.df['user_experience_level'].fillna('unknown')
                X['user_experience_level'] = self.label_encoders['user_experience_level'].fit_transform(
                    self.df['user_experience_level'])

            if 'Vehicle Type' in self.df.columns:
                self.label_encoders['Vehicle Type'] = LabelEncoder()
                self.df['Vehicle Type'] = self.df['Vehicle Type'].fillna('Unknown')
                X['vehicle_type_encoded'] = self.label_encoders['Vehicle Type'].fit_transform(self.df['Vehicle Type'])

            if X.isnull().any().any() or y.isnull().any():
                mask = ~X.isnull().any(axis=1) & ~y.isnull()
                X = X[mask]
                y = y[mask]

            self.feature_names = X.columns.tolist()
            return X, y

        except Exception as e:
            raise Exception(f"Ошибка подготовки данных для ML: {str(e)}")

    def train_model(self):
        """Обучение модели машинного обучения"""
        try:
            X, y = self.prepare_features_for_ml()

            if len(X) == 0 or len(y) == 0:
                raise ValueError("Нет данных для обучения после очистки!")

            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            self.feature_names = X_train.columns.tolist()

            X_train_scaled = self.scaler.fit_transform(X_train)
            X_test_scaled = self.scaler.transform(X_test)

            self.model = RandomForestRegressor(
                n_estimators=100,
                max_depth=10,
                random_state=42,
                n_jobs=-1
            )
            self.model.fit(X_train_scaled, y_train)

            y_pred = self.model.predict(X_test_scaled)
            mae = mean_absolute_error(y_test, y_pred)
            r2 = r2_score(y_test, y_pred)

            self.feature_importance = pd.DataFrame({
                'feature': self.feature_names,
                'importance': self.model.feature_importances_
            }).sort_values('importance', ascending=False)

            return mae, r2

        except Exception as e:
            raise Exception(f"Ошибка обучения модели: {str(e)}")

    def predict_price(self, input_features):
        """Предсказание стоимости для новых данных"""
        if self.model is None:
            raise ValueError("Модель не обучена! Сначала обучите модель.")

        try:
            input_df = pd.DataFrame([input_features])

            for feature in self.feature_names:
                if feature not in input_df.columns:
                    input_df[feature] = 0

            input_df = input_df[self.feature_names]
            input_scaled = self.scaler.transform(input_df)
            return self.model.predict(input_scaled)[0]

        except Exception as e:
            raise Exception(f"Ошибка предсказания: {str(e)}")


class ModernUberPredictorGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Uber Price Predictor")
        self.root.geometry("1100x700")
        self.root.configure(bg='#f0f0f0')

        self.predictor = UberPricePredictor()
        self.setup_ui()

    def setup_ui(self):
        """Создание современного интерфейса"""
        style = ttk.Style()
        style.theme_use('clam')

        # Настройка стилей
        style.configure('TFrame', background='#f0f0f0')
        style.configure('TLabel', background='#f0f0f0', foreground='#333333', font=('Arial', 9))
        style.configure('TButton', background='#4CAF50', foreground='white', font=('Arial', 9))
        style.configure('Title.TLabel', font=('Arial', 16, 'bold'), foreground='#2c3e50')

        # Главный контейнер
        main_frame = ttk.Frame(self.root, style='TFrame', padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Заголовок
        header_frame = ttk.Frame(main_frame, style='TFrame')
        header_frame.pack(fill=tk.X, pady=(0, 15))

        title_label = ttk.Label(header_frame,
                               text="Uber Price Predictor",
                               style='Title.TLabel')
        title_label.pack()

        subtitle_label = ttk.Label(header_frame,
                                  text="AI-powered ride cost estimation",
                                  style='TLabel')
        subtitle_label.pack(pady=(5, 0))

        # Панель управления
        control_frame = ttk.Frame(main_frame, style='TFrame')
        control_frame.pack(fill=tk.X, pady=10)

        self.load_btn = ttk.Button(control_frame,
                                   text="Load Data",
                                   command=self.load_data)
        self.load_btn.pack(side=tk.LEFT, padx=(0, 10))

        self.train_btn = ttk.Button(control_frame,
                                    text="Train Model",
                                    command=self.train_model,
                                    state=tk.DISABLED)
        self.train_btn.pack(side=tk.LEFT, padx=(0, 10))

        self.calculate_btn = ttk.Button(control_frame,
                                        text="Calculate Trip",
                                        command=self.show_calculator,
                                        state=tk.DISABLED)
        self.calculate_btn.pack(side=tk.LEFT)

        # Основной контент
        content_frame = ttk.Frame(main_frame, style='TFrame')
        content_frame.pack(fill=tk.BOTH, expand=True, pady=10)

        # Левая панель - калькулятор
        self.left_frame = ttk.Frame(content_frame, style='TFrame', width=350)
        self.left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        self.left_frame.pack_propagate(False)

        self.setup_calculator()

        # Правая панель - результаты
        self.right_frame = ttk.Frame(content_frame, style='TFrame')
        self.right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self.setup_results_area()

        # Статус бар
        self.status_var = tk.StringVar(value="Ready to work. Load data to start.")
        status_bar = ttk.Label(main_frame, textvariable=self.status_var,
                               style='TLabel', relief='sunken', padding=5)
        status_bar.pack(fill=tk.X, side=tk.BOTTOM)

    def setup_calculator(self):
        """Настройка панели калькулятора"""
        calc_header = ttk.Label(self.left_frame,
                               text="Trip Calculator",
                               font=('Arial', 12, 'bold'),
                               background='#e0e0e0',
                               padding=8)
        calc_header.pack(fill=tk.X)

        # Форма ввода параметров
        form_frame = ttk.Frame(self.left_frame, style='TFrame')
        form_frame.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

        # Параметры поездки
        parameters = [
            ("Hour (0-23):", "hour"),
            ("Day of week (0-6):", "day_of_week"),
            ("Temperature (°C):", "temperature"),
            ("Precipitation (mm):", "precipitation"),
            ("Demand level (1-3):", "demand_surge"),
            ("Distance (km):", "trip_distance_km"),
            ("Duration (min):", "estimated_duration_min"),
            ("Traffic density (0-1):", "area_traffic_density")
        ]

        self.entry_vars = {}

        for i, (label_text, var_name) in enumerate(parameters):
            frame = ttk.Frame(form_frame, style='TFrame')
            frame.pack(fill=tk.X, pady=4)

            label = ttk.Label(frame, text=label_text, style='TLabel', width=20)
            label.pack(side=tk.LEFT)

            var = tk.StringVar(value="0")
            entry = ttk.Entry(frame, textvariable=var, width=12)
            entry.pack(side=tk.RIGHT)

            self.entry_vars[var_name] = var

        # Чекбоксы
        check_frame = ttk.Frame(form_frame, style='TFrame')
        check_frame.pack(fill=tk.X, pady=8)

        self.is_weekend_var = tk.BooleanVar()
        weekend_cb = ttk.Checkbutton(check_frame, text="Weekend",
                                     variable=self.is_weekend_var, style='TLabel')
        weekend_cb.pack(anchor=tk.W)

        self.is_peak_var = tk.BooleanVar()
        peak_cb = ttk.Checkbutton(check_frame, text="Peak hours",
                                  variable=self.is_peak_var, style='TLabel')
        peak_cb.pack(anchor=tk.W)

        self.is_rainy_var = tk.BooleanVar()
        rainy_cb = ttk.Checkbutton(check_frame, text="Rainy weather",
                                   variable=self.is_rainy_var, style='TLabel')
        rainy_cb.pack(anchor=tk.W)

        self.is_city_center_var = tk.BooleanVar()
        city_cb = ttk.Checkbutton(check_frame, text="City center",
                                  variable=self.is_city_center_var, style='TLabel')
        city_cb.pack(anchor=tk.W)

        # Кнопка расчета
        calc_btn = ttk.Button(form_frame,
                              text="Calculate Price",
                              command=self.calculate_ride)
        calc_btn.pack(fill=tk.X, pady=8)

        # Поле результата
        result_frame = ttk.Frame(form_frame, style='TFrame')
        result_frame.pack(fill=tk.X, pady=4)

        self.result_var = tk.StringVar(value="Enter trip parameters")
        result_label = ttk.Label(result_frame,
                                textvariable=self.result_var,
                                font=('Arial', 14, 'bold'),
                                background='#f0f0f0',
                                foreground='#e74c3c',
                                padding=8)
        result_label.pack(fill=tk.X)

    def setup_results_area(self):
        """Настройка области результатов"""
        # Вкладки
        notebook = ttk.Notebook(self.right_frame)
        notebook.pack(fill=tk.BOTH, expand=True)

        # Вкладка логов
        log_frame = ttk.Frame(notebook, style='TFrame')
        notebook.add(log_frame, text='Logs')

        self.text_area = scrolledtext.ScrolledText(log_frame,
                                                   wrap=tk.WORD,
                                                   font=('Consolas', 9),
                                                   bg='#ffffff',
                                                   fg='#000000',
                                                   padx=10,
                                                   pady=10)
        self.text_area.pack(fill=tk.BOTH, expand=True)

        # Вкладка статистики
        stats_frame = ttk.Frame(notebook, style='TFrame')
        notebook.add(stats_frame, text='Statistics')

        # Вкладка графиков
        charts_frame = ttk.Frame(notebook, style='TFrame')
        notebook.add(charts_frame, text='Charts')

    def log_message(self, message):
        """Вывод сообщений в текстовую область"""
        self.text_area.insert(tk.END, message + "\n")
        self.text_area.see(tk.END)
        self.root.update()

    def clear_logs(self):
        """Очистка логов"""
        self.text_area.delete(1.0, tk.END)

    def load_data(self):
        """Загрузка данных"""
        try:
            self.status_var.set("Loading data...")
            self.load_btn.config(state=tk.DISABLED)

            try:
                df = self.predictor.load_data('ncr_ride_bookings.csv')
            except FileNotFoundError:
                self.create_demo_data()
                df = self.predictor.load_data('ncr_ride_bookings.csv')

            self.predictor.create_additional_features()

            self.status_var.set(f"Data loaded: {len(df)} records")
            self.train_btn.config(state=tk.NORMAL)

            self.clear_logs()
            self.log_message("=" * 40)
            self.log_message("DATA SUCCESSFULLY LOADED")
            self.log_message("=" * 40)
            self.log_message(f"Records: {df.shape[0]:,}")
            self.log_message(f"Columns: {df.shape[1]}")
            self.log_message(f"Average price: {df['Booking Value'].mean():.2f} RUB")
            self.log_message("")
            self.log_message("Additional features created")
            self.log_message("Model ready for training")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load data:\n{str(e)}")
            self.status_var.set("Error loading data")
        finally:
            self.load_btn.config(state=tk.NORMAL)

    def create_demo_data(self):
        """Создание демо-данных"""
        np.random.seed(42)
        n_records = 1000

        demo_data = {
            'Date': pd.date_range('2024-01-01', periods=n_records).strftime('%Y-%m-%d'),
            'Time': [f"{np.random.randint(0, 24):02d}:{np.random.randint(0, 60):02d}" for _ in range(n_records)],
            'Booking Value': np.random.gamma(2, 100, n_records) + 100,
            'Vehicle Type': np.random.choice(['Auto', 'Mini', 'Prime Sedan', 'SUV'], n_records)
        }

        df = pd.DataFrame(demo_data)
        df.to_csv('ncr_ride_bookings.csv', index=False)
        self.log_message("Created demo data file")

    def train_model(self):
        """Обучение модели"""
        try:
            self.status_var.set("Training model...")
            self.train_btn.config(state=tk.DISABLED)

            mae, r2 = self.predictor.train_model()

            self.status_var.set(f"Model trained | MAE: {mae:.2f} | R²: {r2:.4f}")
            self.calculate_btn.config(state=tk.NORMAL)

            self.log_message("")
            self.log_message("=" * 40)
            self.log_message("MODEL TRAINED")
            self.log_message("=" * 40)
            self.log_message(f"Mean Absolute Error: {mae:.2f} RUB")
            self.log_message(f"R² Score: {r2:.4f}")
            self.log_message("")
            self.log_message("TOP 5 IMPORTANT FEATURES:")

            for i, (_, row) in enumerate(self.predictor.feature_importance.head(5).iterrows(), 1):
                self.log_message(f"   {i}. {row['feature']}: {row['importance']:.3f}")

            self.log_message("")
            self.log_message("Calculator ready to use!")

        except Exception as e:
            messagebox.showerror("Error", f"Model training error:\n{str(e)}")
            self.status_var.set("Training error")

    def show_calculator(self):
        """Показать калькулятор"""
        self.left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))

    def calculate_ride(self):
        """Расчет стоимости поездки"""
        try:
            # Сбор данных из формы
            input_features = {
                'hour': float(self.entry_vars['hour'].get()),
                'day_of_week': float(self.entry_vars['day_of_week'].get()),
                'is_weekend': 1 if self.is_weekend_var.get() else 0,
                'month': 6,
                'is_peak_hours': 1 if self.is_peak_var.get() else 0,
                'temperature': float(self.entry_vars['temperature'].get()),
                'precipitation': float(self.entry_vars['precipitation'].get()),
                'is_rainy': 1 if self.is_rainy_var.get() else 0,
                'demand_surge': float(self.entry_vars['demand_surge'].get()),
                'driver_availability': 0.5,
                'trip_distance_km': float(self.entry_vars['trip_distance_km'].get()),
                'estimated_duration_min': float(self.entry_vars['estimated_duration_min'].get()),
                'is_city_center': 1 if self.is_city_center_var.get() else 0,
                'area_traffic_density': float(self.entry_vars['area_traffic_density'].get()),
                'user_rating': 4.5,
                'fuel_price_index': 1.0,
                'daylight_hours': 12,
                'is_holiday': 0,
                'user_experience_level': 1,
                'vehicle_type_encoded': 0
            }

            predicted_price = self.predictor.predict_price(input_features)

            # Форматируем результат
            result_text = f"{predicted_price:.0f} RUB"
            self.result_var.set(result_text)

            # Логируем расчет
            self.log_message("")
            self.log_message("TRIP CALCULATION:")
            self.log_message(f"   Distance: {input_features['trip_distance_km']} km")
            self.log_message(f"   Duration: {input_features['estimated_duration_min']} min")
            self.log_message(f"   Time: {int(input_features['hour'])}:00")
            self.log_message(f"   Temperature: {input_features['temperature']}°C")
            self.log_message(f"   Precipitation: {input_features['precipitation']} mm")
            self.log_message(f"   Demand: x{input_features['demand_surge']:.1f}")
            self.log_message(f"   Traffic: {input_features['area_traffic_density']:.1f}")
            self.log_message(f"   PREDICTED PRICE: {predicted_price:.0f} RUB")

        except Exception as e:
            messagebox.showerror("Error", f"Calculation error:\n{str(e)}")
            self.result_var.set("Calculation error")

    def run(self):
        """Запуск приложения"""
        self.root.mainloop()


# Запуск приложения
if __name__ == "__main__":
    try:
        print("Starting Uber Price Predictor...")
        app = ModernUberPredictorGUI()
        app.run()
    except Exception as e:
        print(f"Critical error: {e}")
        import traceback
        traceback.print_exc()